Bona tarda,
Avui no he pogut anar al lab i tenia molts dubtes aixi que he avançat com he pogut, potser hi ha alguna cosa sense sentit (espero que no), 
la majoria crec que es coherent pero no m'ha donat temps a testejar tot el que he implementat (he acabat d'implementar 5 min abans de l'entrega).

Respecte al codi, les trucades a sistema block i unblock he fet les seves entrades a la sys_call_table random (5 i 6 crec). Els wrappers he fet amb 
int en comptes de sysenter, ho canviaré per practicar per l'examen no sé si preferieu el sysenter (per fer-ho per un altre entrega).
