#ifndef __MISC_H__
#define __MISC_H__

//void itoa(int a, char *b);

int strlen(char *a);

void breakpoint();

#endif
