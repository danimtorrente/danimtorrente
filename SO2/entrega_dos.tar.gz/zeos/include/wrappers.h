
#ifndef __WRAPPERS_H__
#define __WRAPPERS_H__

int write (int fd, char * buffer, int size);

int gettime();

#endif
