/*
--DEFINICION DE ERRORES
*/

#ifndef __ERRNO_H__
#define __ERRNO_H__

#define ENOSYS -38
#define EBADF -9
#define EACCES -13
#define STANDARD_ERROR -1

#endif
